# Havist Traveller — Web Platform & ERP Management

Sistem terpadu **Halaman Publik (Katalog, Simulasi Paket Sekolah & Korporat, Shareable Micro-Card)** dan **Dashboard Management Internal (Keuangan, Piutang, Vendor, Jadwal Trip, Crew, Sales, CRM & Pusat Dokumen PDF)** untuk **Havist Traveller**.

## Struktur Repository

```text
havistraveller/
├── index.html          # Aplikasi utama Single-Page App (Publik + ERP Multi-Role)
├── api.php             # Endpoint backend PHP untuk simpan/muat JSON & upload media
├── .htaccess           # Konfigurasi HTTPS, proteksi folder storage, & cache control
├── .gitignore          # Pengecualian file database runtime & upload sementara
├── assets/
│   └── foto/           # Folder aset foto destinasi / banner hero statis
├── storage/            # Lokasi penyimpanan database server (havist_db.json)
└── uploads/            # Lokasi penyimpanan foto/video yang diunggah lewat Setting Web
```

## Fitur Utama

1. **Halaman Publik (`#umum`)**
   - **Segment Switcher:** Mode khusus **Paket Sekolah** (*Quad Share* isi 4, FOC 1:10) dan **Paket Korporat** (*Twin Share* isi 2).
   - **Shareable Package & Quote Card (`#paket=0` / `#penawaran=ID`):** Kartu paket ringkas dengan tab *Itinerary | Fasilitas | Galeri* dan tombol *Chat Sekarang* via WhatsApp.
   - **Kalkulator Estimasi Biaya + Sticky Price Bar:** Simulasi harga per pax *real-time* beserta fitur cetak **Surat Estimasi Proposal (PDF)** langsung bagi panitia sekolah/instansi.
2. **Dashboard & ERP Internal (Multi-Role)**
   - **Owner / Management (`owner` / PIN `1234`):** Akses penuh ke seluruh laporan laba bersih, arus kas, piutang, vendor, crew, dan pengaturan web.
   - **Admin Operasional (`admin` / PIN `1234`):** Pelunasan klien, aging piutang, jadwal DP vendor, dan reimburse lapangan.
   - **Sales (`sales` / PIN `1234`):** Kalkulator penawaran, CRM pelanggan, dan pelacakan komisi 5%.
   - **Tour Leader & Media (`tl` / PIN `1234`):** Jadwal bertugas, checklist H-1, laporan kesiapan via WA, dan pengajuan reimburse.

## Cara Update ke GitHub (`irvandinata5-ui/havistraveller`) & Hosting Rumahweb

1. Ekstrak file ZIP repository ini.
2. Unggah/timpa seluruh isi folder ke repositori GitHub **`https://github.com/irvandinata5-ui/havistraveller`** (via *Upload files* di web GitHub atau `git push`).
3. Untuk deploy ke hosting Rumahweb (`havisttraveller.com`), unggah **`index.html`**, **`api.php`**, dan **`.htaccess`** ke folder **`public_html`** di cPanel File Manager.
