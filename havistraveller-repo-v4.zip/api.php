<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$baseDir = __DIR__;
$storageDir = $baseDir . '/storage';
$uploadsDir = $baseDir . '/uploads';
$dbFile = $storageDir . '/havist_db.json';

if (!is_dir($storageDir)) {
    @mkdir($storageDir, 0755, true);
}
if (!is_dir($uploadsDir)) {
    @mkdir($uploadsDir, 0755, true);
}

// Protect storage directory from direct web browsing
$htaccessStorage = $storageDir . '/.htaccess';
if (!file_exists($htaccessStorage)) {
    @file_put_contents($htaccessStorage, "Deny from all\n");
}

$action = isset($_GET['action']) ? $_GET['action'] : 'load';

if ($action === 'load') {
    if (file_exists($dbFile)) {
        $raw = file_get_contents($dbFile);
        if ($raw !== false && strlen(trim($raw)) > 2) {
            echo $raw;
            exit;
        }
    }
    echo json_encode(['_empty' => true, '_server' => 'havisttraveller.com']);
    exit;
}

if ($action === 'save') {
    $body = file_get_contents('php://input');
    $decoded = json_decode($body, true);
    if (!is_array($decoded)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Invalid JSON payload']);
        exit;
    }
    $decoded['_serverSavedAt'] = date('c');
    $ok = file_put_contents($dbFile, json_encode($decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    if ($ok === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Failed to write storage/havist_db.json']);
        exit;
    }
    echo json_encode(['ok' => true, 'savedAt' => $decoded['_serverSavedAt']]);
    exit;
}

if ($action === 'upload') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'No valid file uploaded']);
        exit;
    }
    $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'webm'];
    if (!in_array($ext, $allowed, true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Unsupported file extension']);
        exit;
    }
    $safeName = 'hvst_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
    $destPath = $uploadsDir . '/' . $safeName;
    if (!move_uploaded_file($_FILES['file']['tmp_name'], $destPath)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Failed to move uploaded file']);
        exit;
    }
    echo json_encode(['ok' => true, 'url' => 'uploads/' . $safeName]);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Unknown action']);
